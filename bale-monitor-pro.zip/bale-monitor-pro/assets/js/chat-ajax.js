jQuery(document).ready(function($) {
    var currentUserId = baleChat.selectedUser || '';
    var lastMessageId = 0;
    var pollInterval = 3000;
    var pollTimer = null;
    var isSending = false;
    var currentRequest = null; // برای لغو درخواست‌های قبلی

    function loadMessages(userId, isReset = false) {
        if (!userId) return;

        // اگر یک درخواست در جریان است، آن را لغو کن تا با کلیک جدید تداخل نکند
        if (isReset && currentRequest) {
            currentRequest.abort();
        }

        if (isReset) {
            lastMessageId = 0;
            $('#bale-messages-area').html('<div class="bale-loading">در حال بارگذاری پیام‌ها...</div>');
        }

        currentRequest = $.post(ajaxurl, {
            action: 'bale_get_messages',
            user_id: userId,
            nonce: baleChat.nonce,
            last_id: lastMessageId
        }, function(response) {
            if (response.success) {
                if (isReset) $('#bale-messages-area').empty();
                
                if (response.data.messages && response.data.messages.length > 0) {
                    appendMessages(response.data.messages);
                    // آپدیت آخرین ID دریافت شده
                    var newLastId = response.data.messages[response.data.messages.length - 1].id;
                    lastMessageId = Math.max(lastMessageId, newLastId);
                } else if (isReset) {
                    $('#bale-messages-area').html('<div class="bale-empty">پیامی یافت نشد.</div>');
                }
            }
        }).always(function() {
            currentRequest = null;
        });
    }

    function appendMessages(messages) {
        var container = $('#bale-messages-area');
        var html = '';
        $.each(messages, function(i, msg) {
            if ($('#msg-' + msg.id).length > 0) return;

            var isOwn = (msg.username === 'Admin');
            var messageBody = '';

            // منطق جدید: اگر نوع پیام تصویر بود، تگ img بساز
            if (msg.type === 'image') {
                messageBody = '<img src="' + msg.message + '" class="bale-clickable-img" style="max-width: 250px; border-radius: 10px; cursor: pointer; display: block; margin: 5px 0;" onclick="window.open(this.src)">';
            } else {
                messageBody = nl2br(msg.message);
            }

            html += '<div id="msg-' + msg.id + '" class="bale-message-row ' + (isOwn ? 'own' : 'other') + '">' +
                '<div class="bale-message-bubble">' +
                (!isOwn ? '<div class="bale-message-sender">' + msg.username + '</div>' : '') +
                '<div class="bale-message-text">' + messageBody + '</div>' +
                '<div class="bale-message-time">' + msg.time + '</div>' +
                '</div></div>';
        });
        
        container.append(html);
        if (messages.length > 0) {
            container.scrollTop(container[0].scrollHeight);
        }
    }

    // رویداد کلیک مخاطب
    $(document).on('click', '.bale-chat-item', function() {
        var userId = $(this).data('user-id').toString();
        var userName = $(this).data('username');

        // حذف استایل قبلی و اعمال به فعلی
        $('.bale-chat-item').removeClass('active');
        $(this).addClass('active');

        // تنظیمات یوزر جدید
        currentUserId = userId;
        $('#bale-current-username').text(userName);
        $('#bale-input-area').show();

        // لود پیام‌ها با ریست کامل
        loadMessages(userId, true);
    });

    // ارسال پیام
    $('#bale-send-btn').on('click', function() {
        var $input = $('#bale-message-input');
        var message = $input.val().trim();
        
        if (isSending || !message || !currentUserId) return;

        isSending = true;
        var $btn = $(this);
        $btn.prop('disabled', true);

        $.post(ajaxurl, {
            action: 'bale_send_message',
            user_id: currentUserId,
            message: message,
            nonce: baleChat.nonce
        }, function(response) {
            if (response.success) {
                $input.val('');
                loadMessages(currentUserId, false); // بلافاصله چک کن پیام جدید اومده یا نه
            }
        }).always(function() {
            isSending = false;
            $btn.prop('disabled', false);
        });
    });

    function nl2br(str) { 
        if (!str) return '';
        return str.replace(/\n/g, '<br>'); 
    }

    // شروع Polling
    setInterval(function() {
        if (currentUserId && !currentRequest && !isSending) {
            loadMessages(currentUserId, false);
        }
    }, pollInterval);

    // لود اولیه اگر یوزر از قبل انتخاب شده
    if (currentUserId) {
        $('.bale-chat-item[data-user-id="' + currentUserId + '"]').click();
    }
});