<?php
/**
 * Plugin Name: Bale Monitor Pro
 * Description: Official Bale Bot API Integration based on docs.bale.ai
 * Version: 4.0
 * Author: Hadi Dev
 * Text Domain: bale-monitor-pro
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('BMP_VERSION', '4.0');
define('BMP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BMP_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include autoloader
spl_autoload_register(function ($class) {
    $prefix = 'BaleMonitorPro\\';
    $base_dir = BMP_PLUGIN_DIR . 'includes/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Activation hook
register_activation_hook(__FILE__, ['BaleMonitorPro\\Bootstrap', 'activate']);
// Deactivation hook
register_deactivation_hook(__FILE__, ['BaleMonitorPro\\Bootstrap', 'deactivate']);

// Initialize plugin
add_action('plugins_loaded', ['BaleMonitorPro\\Bootstrap', 'init']);

// Enqueue admin scripts and styles
add_action('admin_enqueue_scripts', 'bale_monitor_admin_scripts');

function bale_monitor_admin_scripts($hook) {
    // بررسی صفحه پلاگین
    $screen = get_current_screen();
    if (!$screen || strpos($screen->id, 'bale-monitor') === false) {
        return;
    }
    
    wp_enqueue_style('bale-chat-css', BMP_PLUGIN_URL . 'assets/css/chat-style.css', [], BMP_VERSION);
    wp_enqueue_script('bale-chat-js', BMP_PLUGIN_URL . 'assets/js/chat-ajax.js', ['jquery'], BMP_VERSION, true);
    
    // اصلاح: ارسال اطلاعات کاربر انتخاب شده به جاوااسکریپت
    wp_localize_script('bale-chat-js', 'baleChat', [
        'nonce'          => wp_create_nonce('bale_chat_nonce'),
        'currentAdminId' => get_current_user_id(),
        'selectedUser'   => isset($_GET['user_id']) ? sanitize_text_field($_GET['user_id']) : ''
    ]);
}

// =============== AJAX handlers ===============
add_action('wp_ajax_bale_send_message', 'bale_send_message_callback');
add_action('wp_ajax_bale_get_messages', 'bale_get_messages_callback');

function bale_send_message_callback() {
    check_ajax_referer('bale_chat_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $user_id = sanitize_text_field($_POST['user_id']);
    $message = sanitize_textarea_field($_POST['message']);

    // ذخیره در دیتابیس به عنوان پیام ارسالی از طرف ادمین
    $service = new BaleMonitorPro\Admin\Services\MessageService();
    $inserted = $service->addMessage($user_id, 'Admin', $message);

    if ($inserted) {
        global $wpdb;
        $new_id = $wpdb->insert_id;

        // ارسال به API بله (اگر توکن وجود داشته باشد)
        $token = get_option('bale_bot_token');
        $client = null;
        if ($token) {
            $client = new BaleMonitorPro\Api\Client();
            $client->request('sendMessage', [
                'chat_id' => $user_id,
                'text'    => $message
            ]);
        }

        // بررسی اینکه آیا پیام یک دستور ربات است (شروع با /)
        if (strpos($message, '/') === 0) {
            if (class_exists('BaleMonitorPro\Api\Webhook')) {
                $webhook = new BaleMonitorPro\Api\Webhook($service, $client);
                if (method_exists($webhook, 'handleCommand')) {
                    $webhook->handleCommand($message, $user_id, 'Admin', 'Admin');
                }
            } else {
                bale_handle_simple_command($message, $user_id);
            }
        }

        wp_send_json_success([
            'message' => [
                'id'       => $new_id,
                'user_id'  => $user_id,
                'username' => 'Admin',
                'message'  => stripslashes($message),
                'time'     => BaleMonitorPro\Utils\Jalali::toJalali(current_time('mysql'))
            ]
        ]);
    } else {
        wp_send_json_error(['message' => 'خطا در ذخیره پیام']);
    }
}

function bale_get_messages_callback() {
    check_ajax_referer('bale_chat_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $user_id = sanitize_text_field($_POST['user_id']);
    $last_id = intval($_POST['last_id']);

    global $wpdb;
    $table = $wpdb->prefix . 'bale_messages';
    
    // اصلاح اصلی: لود تاریخچه در صورت صفر بودن last_id
    if ($last_id === 0) {
        // دریافت ۵۰ پیام آخر برای شروع چت
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM (SELECT * FROM $table WHERE bale_user_id = %s ORDER BY id DESC LIMIT 50) as sub ORDER BY id ASC",
            $user_id
        ));
    } else {
        // دریافت فقط پیام‌های جدیدتر
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE bale_user_id = %s AND id > %d ORDER BY id ASC",
            $user_id, $last_id
        ));
    }

    $formatted = [];
    foreach ($messages as $msg) {
        $content = stripslashes($msg->message);
        
        // تشخیص تصویر: اگر متن پیام با http شروع شود و پسوند عکس داشته باشد
        $is_image = preg_match('/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i', $content);

        $formatted[] = [
            'id'       => intval($msg->id),
            'user_id'  => $msg->bale_user_id,
            'username' => $msg->username,
            'message'  => $content,
            'time'     => BaleMonitorPro\Utils\Jalali::toJalali($msg->created_at),
            'type'     => $is_image ? 'image' : 'text'
        ];
    }

    wp_send_json_success(['messages' => $formatted]);
}

function bale_handle_simple_command($command, $user_id) {
    if ($command === '/start') {
        error_log("Command /start received for user $user_id");
    } elseif ($command === '/profile') {
        error_log("Command /profile received for user $user_id");
    }
}