<?php
/**
 * کلاس مدیریت صفحه ادمین (نسخه بازنویسی‌شده با معماری جدید)
 * 
 * @package BaleMonitorPro
 * @subpackage Admin
 */

namespace BaleMonitorPro\Admin;

use BaleMonitorPro\Admin\Views\TokenFormView;
use BaleMonitorPro\Admin\Views\WebhookSectionView;
use BaleMonitorPro\Admin\Views\MessagesView;
use BaleMonitorPro\Admin\Services\TokenService;
use BaleMonitorPro\Admin\Services\WebhookService;
use BaleMonitorPro\Admin\Services\MessageService;

class AdminPage
{
    /**
     * @var TokenService
     */
    private $tokenService;

    /**
     * @var WebhookService
     */
    private $webhookService;

    /**
     * @var MessageService
     */
    private $messageService;

    /**
     * @var TokenFormView
     */
    private $tokenFormView;

    /**
     * @var WebhookSectionView
     */
    private $webhookSectionView;

    /**
     * @var MessagesView
     */
    private $messagesView;

    /**
     * سازنده با تزریق وابستگی‌ها
     */
    public function __construct(
        TokenService $tokenService,
        WebhookService $webhookService,
        MessageService $messageService,
        TokenFormView $tokenFormView,
        WebhookSectionView $webhookSectionView,
        MessagesView $messagesView
    ) {
        $this->tokenService = $tokenService;
        $this->webhookService = $webhookService;
        $this->messageService = $messageService;
        $this->tokenFormView = $tokenFormView;
        $this->webhookSectionView = $webhookSectionView;
        $this->messagesView = $messagesView;
    }

    /**
     * ثبت هوک‌ها
     */
    public function registerHooks()
    {
        add_action('admin_menu', [$this, 'addMenu']);
        add_action('admin_post_bale_clear_history', [$this, 'handleClearHistory']);
        add_action('admin_post_bale_delete_user_messages', [$this, 'handleDeleteUserMessages']);
    }

    /**
     * افزودن منو
     */
    public function addMenu()
    {
        add_menu_page(
            __('مانیتورینگ بله', 'bale-monitor-pro'),
            __('مانیتوینگ بله', 'bale-monitor-pro'),
            'manage_options',
            'bale-monitor',
            [$this, 'renderPage'],
            'dashicons-format-chat',
            6
        );
    }

    /**
     * رندر صفحه اصلی
     */
    public function renderPage()
    {
        // پردازش ذخیره توکن
        if (isset($_POST['bale_token']) && check_admin_referer('bale_save_token', 'bale_token_nonce')) {
            $this->tokenService->saveToken($_POST['bale_token']);
            echo '<div class="updated"><p>' . __('توکن ذخیره شد ✅', 'bale-monitor-pro') . '</p></div>';
        }

        $token = get_option('bale_bot_token');

        ?>
        <div class="wrap">
            <h1><?php _e('مدیریت بازوی بله', 'bale-monitor-pro'); ?></h1>

            <?php $this->tokenFormView->render($token); ?>
            <hr>

            <?php if ($token): ?>
                <?php
                // پردازش Webhook
                $setResult = null;
                $checkResult = null;
                $webhookUrl = rest_url('bale/v1/webhook');

                if (isset($_POST['set_webhook']) && check_admin_referer('bale_webhook_action')) {
                    $setResult = $this->webhookService->setWebhook($webhookUrl);
                }
                if (isset($_POST['check_webhook']) && check_admin_referer('bale_webhook_action')) {
                    $checkResult = $this->webhookService->getWebhookInfo();
                }

                $this->webhookSectionView->render($webhookUrl, $setResult, $checkResult);
                ?>
            <?php endif; ?>

            <?php
            // داده‌های بخش پیام‌ها
            $users = $this->messageService->getUsersWithStats();
            $selectedUserId = isset($_GET['user_id']) ? sanitize_text_field($_GET['user_id']) : '';

            if ($selectedUserId) {
                $messages = $this->messageService->getMessagesByUser($selectedUserId);
                // پیدا کردن نام کاربر انتخاب شده
                $selectedUser = array_filter($users, function($u) use ($selectedUserId) {
                    return $u->bale_user_id == $selectedUserId;
                });
                $selectedUserName = !empty($selectedUser) ? reset($selectedUser)->username : '';
            } else {
                $messages = $this->messageService->getRecentMessages(50);
                $selectedUserName = '';
            }

            // رندر بخش پیام‌ها با طراحی جدید
            $this->messagesView->renderClearAllButton();
            ?>
            <div class="bale-chat-wrapper">
                <?php $this->messagesView->renderUserList($users, $selectedUserId); ?>
                <?php $this->messagesView->renderChatArea($messages, $selectedUserId, $selectedUserName); ?>
            </div>
        </div>
        <?php
    }

    /**
     * پردازشگر پاک‌سازی کل تاریخچه
     */
    public function handleClearHistory()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('دسترسی غیرمجاز', 'bale-monitor-pro'));
        }
        check_admin_referer('bale_clear_history_nonce', 'bale_nonce');

        $this->messageService->clearAll();

        wp_redirect(add_query_arg('cleared', '1', wp_get_referer()));
        exit;
    }

    /**
     * پردازشگر حذف پیام‌های یک کاربر
     */
    public function handleDeleteUserMessages()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('دسترسی غیرمجاز', 'bale-monitor-pro'));
        }
        check_admin_referer('bale_delete_user_nonce', 'bale_nonce');

        if (!isset($_GET['user_id'])) {
            wp_redirect(wp_get_referer());
            exit;
        }

        $this->messageService->deleteByUser(sanitize_text_field($_GET['user_id']));

        wp_redirect(add_query_arg('deleted', '1', wp_get_referer()));
        exit;
    }
}