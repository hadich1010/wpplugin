<?php
namespace BaleMonitorPro\Admin\Services;

class MessageService
{
    private $table;

    public function __construct()
    {
        global $wpdb;
        $this->table = $wpdb->prefix . 'bale_messages';
    }

    public function getUsersWithStats()
    {
        global $wpdb;
        return $wpdb->get_results("
            SELECT bale_user_id, 
                   MAX(username) as username, 
                   COUNT(*) as msg_count,
                   MAX(created_at) as last_msg_time
            FROM {$this->table}
            GROUP BY bale_user_id
            ORDER BY last_msg_time DESC
        ");
    }

    public function getMessagesByUser($userId, $order = 'ASC')
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE bale_user_id = %s ORDER BY created_at $order",
            $userId
        ));
    }

    public function getRecentMessages($limit = 50)
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table} ORDER BY created_at DESC LIMIT %d",
            $limit
        ));
    }

    public function addMessage($userId, $username, $message)
    {
        global $wpdb;
        return $wpdb->insert($this->table, [
            'bale_user_id' => $userId,
            'username'     => $username,
            'message'      => $message,
            'created_at'   => current_time('mysql')
        ]);
    }

    public function clearAll()
    {
        global $wpdb;
        return $wpdb->query("TRUNCATE TABLE {$this->table}");
    }

    public function deleteByUser($userId)
    {
        global $wpdb;
        return $wpdb->delete($this->table, ['bale_user_id' => $userId], ['%s']);
    }
}