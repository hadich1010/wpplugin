<?php

/**
 * سرویس مدیریت توکن
 * 
 * @package BaleMonitorPro
 * @subpackage Admin\Services
 */

namespace BaleMonitorPro\Admin\Services;

use BaleMonitorPro\Api\Client;

class TokenService
{
    /**
     * @var Client
     */
    private $client;

    /**
     * سازنده
     *
     * @param Client $client
     */
    public function __construct(Client $client)
    {
        $this->client = $client;
    }

    /**
     * ذخیره توکن
     *
     * @param string $token
     * @return void
     */
    public function saveToken($token)
    {
        $this->client->setToken(sanitize_text_field($token));
    }
}
