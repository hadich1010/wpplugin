<?php

/**
 * سرویس مدیریت Webhook
 * 
 * @package BaleMonitorPro
 * @subpackage Admin\Services
 */

namespace BaleMonitorPro\Admin\Services;

use BaleMonitorPro\Api\Client;

class WebhookService
{
    /**
     * @var Client
     */
    private $client;

    /**
     * سازنده
     *
     * @param Client $client
     */
    public function __construct(Client $client)
    {
        $this->client = $client;
    }

    /**
     * ثبت Webhook
     *
     * @param string $url
     * @return mixed
     */
    public function setWebhook($url)
    {
        return $this->client->request('setWebhook', ['url' => $url]);
    }

    /**
     * دریافت اطلاعات Webhook
     *
     * @return mixed
     */
    public function getWebhookInfo()
    {
        return $this->client->request('getWebhookInfo');
    }
}
