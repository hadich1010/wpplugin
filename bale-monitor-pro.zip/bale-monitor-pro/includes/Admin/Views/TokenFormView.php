<?php

/**
 * فرم ورود توکن ربات
 * 
 * @package BaleMonitorPro
 * @subpackage Admin\Views
 */

namespace BaleMonitorPro\Admin\Views;

class TokenFormView
{
    /**
     * نمایش فرم توکن
     *
     * @param string $token توکن فعلی
     * @return void
     */
    public function render($token)
    {
?>
        <form method="post" action="">
            <?php wp_nonce_field('bale_save_token', 'bale_token_nonce'); ?>
            <label><strong><?php _e('توکن بازو:', 'bale-monitor-pro'); ?></strong></label><br>
            <input type="text" name="bale_token" value="<?php echo esc_attr($token); ?>" style="width:500px">
            <br><br>
            <?php submit_button(__('ذخیره توکن', 'bale-monitor-pro'), 'primary', 'submit', false); ?>
        </form>
<?php
    }
}
