<?php

/**
 * رندر کننده پاسخ‌های API
 * 
 * @package BaleMonitorPro
 * @subpackage Admin\Views
 */

namespace BaleMonitorPro\Admin\Views;

class ApiResultRenderer
{
    /**
     * نمایش نتیجه API درون تگ pre
     *
     * @param mixed $result پاسخ API
     * @return void
     */
    public function render($result)
    {
        echo '<h3>' . __('پاسخ API:', 'bale-monitor-pro') . '</h3>';
        echo '<pre>';
        print_r($result);
        echo '</pre><hr>';
    }
}
