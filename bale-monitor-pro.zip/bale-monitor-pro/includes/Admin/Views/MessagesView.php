<?php
/**
 * نمایش پیام‌ها و کاربران - طراحی شبیه بله/تلگرام
 * 
 * @package BaleMonitorPro
 * @subpackage Admin\Views
 */

namespace BaleMonitorPro\Admin\Views;

use BaleMonitorPro\Utils\Jalali;

class MessagesView
{
    /**
     * دکمه پاک‌سازی کل تاریخچه
     */
    public function renderClearAllButton()
    {
        ?>
        <div style="margin-bottom:20px;">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                <input type="hidden" name="action" value="bale_clear_history">
                <?php wp_nonce_field('bale_clear_history_nonce', 'bale_nonce'); ?>
                <button type="submit" class="button button-secondary" style="background-color:#dc3232; color:white; border-color:#dc3232;" onclick="return confirm('<?php esc_attr_e('آیا از پاک کردن تمام تاریخچه مطمئن هستید؟', 'bale-monitor-pro'); ?>');">
                    🗑 <?php _e('پاک کردن تمام تاریخچه', 'bale-monitor-pro'); ?>
                </button>
            </form>
        </div>
        <?php
    }

    /**
     * نمایش لیست کاربران (سایدبار)
     */
    public function renderUserList($users, $selectedUserId)
    {
        ?>
        <div class="bale-sidebar">
            <div class="bale-sidebar-header">
                <h3><?php _e('مکالمات', 'bale-monitor-pro'); ?></h3>
                <input type="text" id="bale-search" placeholder="<?php esc_attr_e('جستجو...', 'bale-monitor-pro'); ?>" class="bale-search-input">
            </div>
            <div class="bale-chat-list" id="bale-chat-list">
                <?php foreach ($users as $user): 
                    $activeClass = ($selectedUserId == $user->bale_user_id) ? 'active' : '';
                    $lastMsgTime = Jalali::toJalali($user->last_msg_time);
                    $avatar = '👤'; // می‌توانید از حرف اول نام یا آواتار استفاده کنید
                ?>
                <div class="bale-chat-item <?php echo $activeClass; ?>" data-user-id="<?php echo esc_attr($user->bale_user_id); ?>" data-username="<?php echo esc_attr($user->username); ?>">
                    <div class="bale-avatar"><?php echo $avatar; ?></div>
                    <div class="bale-chat-info">
                        <div class="bale-chat-name"><?php echo esc_html($user->username); ?></div>
                        <div class="bale-chat-last"><?php echo $user->msg_count; ?> پیام • <?php echo $lastMsgTime; ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    /**
     * نمایش بخش چت
     */
    public function renderChatArea($messages, $selectedUserId = null, $selectedUserName = '')
    {
        ?>
        <div class="bale-main-chat" data-current-user="<?php echo esc_attr($selectedUserId); ?>">
            <div class="bale-chat-header">
                <div class="bale-chat-header-info">
                    <span class="bale-header-avatar">👤</span>
                    <span class="bale-header-name" id="bale-current-username"><?php echo $selectedUserId ? esc_html($selectedUserName) : __('انتخاب کاربر', 'bale-monitor-pro'); ?></span>
                </div>
            </div>
            <div class="bale-messages-area" id="bale-messages-area">
                <?php $this->renderMessages($messages); ?>
            </div>
            <div class="bale-input-area" id="bale-input-area" style="<?php echo !$selectedUserId ? 'display:none;' : ''; ?>">
                <textarea id="bale-message-input" placeholder="<?php esc_attr_e('پیام خود را بنویسید...', 'bale-monitor-pro'); ?>" rows="1"></textarea>
                <button id="bale-send-btn" class="button button-primary">✈</button>
            </div>
        </div>
        <?php
    }

    /**
     * رندر پیام‌ها
     */
    private function renderMessages($messages)
    {
        if (empty($messages)) {
            echo '<div class="bale-empty">📭 ' . __('هیچ پیامی وجود ندارد', 'bale-monitor-pro') . '</div>';
            return;
        }
        foreach ($messages as $msg) {
            $isOwn = ($msg->username == 'Admin');
            $time = Jalali::toJalali($msg->created_at);
            ?>
            <div class="bale-message-row <?php echo $isOwn ? 'own' : 'other'; ?>">
                <div class="bale-message-bubble">
                    <?php if (!$isOwn): ?>
                        <div class="bale-message-sender"><?php echo esc_html($msg->username); ?></div>
                    <?php endif; ?>
                    <div class="bale-message-text"><?php echo nl2br(esc_html($msg->message)); ?></div>
                    <div class="bale-message-time"><?php echo $time; ?></div>
                </div>
            </div>
            <?php
        }
    }
}