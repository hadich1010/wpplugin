<?php

/**
 * بخش تنظیمات Webhook
 * 
 * @package BaleMonitorPro
 * @subpackage Admin\Views
 */

namespace BaleMonitorPro\Admin\Views;

class WebhookSectionView
{
    /**
     * @var ApiResultRenderer
     */
    private $apiResultRenderer;

    /**
     * سازنده
     *
     * @param ApiResultRenderer $apiResultRenderer
     */
    public function __construct(ApiResultRenderer $apiResultRenderer)
    {
        $this->apiResultRenderer = $apiResultRenderer;
    }

    /**
     * نمایش بخش Webhook
     *
     * @param string $webhookUrl آدرس Webhook
     * @param mixed $setResult نتیجه ثبت webhook (اختیاری)
     * @param mixed $checkResult نتیجه بررسی webhook (اختیاری)
     * @return void
     */
    public function render($webhookUrl, $setResult = null, $checkResult = null)
    {
        if ($setResult) {
            $this->apiResultRenderer->render($setResult);
        }
        if ($checkResult) {
            $this->apiResultRenderer->render($checkResult);
        }
?>
        <form method="post" style="display:inline-block;">
            <?php wp_nonce_field('bale_webhook_action'); ?>
            <button name="set_webhook" class="button button-primary"><?php _e('ثبت Webhook', 'bale-monitor-pro'); ?></button>
            <button name="check_webhook" class="button"><?php _e('بررسی وضعیت Webhook', 'bale-monitor-pro'); ?></button>
        </form>
        <p>
            <strong><?php _e('Webhook فعلی:', 'bale-monitor-pro'); ?></strong><br>
            <code><?php echo esc_url($webhookUrl); ?></code>
        </p>
        <hr>
<?php
    }
}
