<?php
namespace BaleMonitorPro\Database;

class Database
{
    private $table;

    public function __construct()
    {
        global $wpdb;
        $this->table = $wpdb->prefix . 'bale_messages'; // تغییر نام جدول
        $this->ensureTable(); // بررسی و ایجاد جدول در صورت نیاز
    }

    /**
     * اطمینان از وجود جدول (ایجاد خودکار اگر نباشد)
     */
    private function ensureTable()
    {
        global $wpdb;
        if ($wpdb->get_var("SHOW TABLES LIKE '{$this->table}'") != $this->table) {
            $this->createTable();
        }
    }

    /**
     * ایجاد جدول (فراخوانی در فعال‌سازی و در صورت نیاز)
     */
    public static function createTable()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'bale_messages'; // هماهنگ با نام جدید
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            bale_user_id VARCHAR(100),
            username VARCHAR(150),
            message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function insertMessage($userId, $username, $message)
    {
        global $wpdb;
        return $wpdb->insert($this->table, [
            'bale_user_id' => sanitize_text_field($userId),
            'username'     => sanitize_text_field($username),
            'message'      => sanitize_textarea_field($message)
        ]);
    }

    public function getUsersWithStats()
    {
        global $wpdb;
        return $wpdb->get_results("
            SELECT 
                bale_user_id, 
                MAX(username) as username, 
                COUNT(*) as msg_count,
                MAX(created_at) as last_msg_time
            FROM {$this->table}
            GROUP BY bale_user_id
            ORDER BY last_msg_time DESC
        ");
    }

    public function getMessagesByUser($userId, $limit = 0, $order = 'ASC')
    {
        global $wpdb;
        $sql = $wpdb->prepare("
            SELECT * FROM {$this->table}
            WHERE bale_user_id = %s
            ORDER BY created_at $order
        ", $userId);
        if ($limit > 0) {
            $sql .= $wpdb->prepare(" LIMIT %d", $limit);
        }
        return $wpdb->get_results($sql);
    }

    public function getRecentMessages($limit = 50)
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("
            SELECT * FROM {$this->table}
            ORDER BY created_at DESC
            LIMIT %d
        ", $limit));
    }

    public function clearAll()
    {
        global $wpdb;
        return $wpdb->query("TRUNCATE TABLE {$this->table}");
    }

    public function deleteByUser($userId)
    {
        global $wpdb;
        return $wpdb->delete($this->table, ['bale_user_id' => sanitize_text_field($userId)]);
    }
}