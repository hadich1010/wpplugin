<?php

namespace BaleMonitorPro\Utils;

class Jalali
{
    /**
     * Convert Gregorian datetime to Jalali (Persian) datetime string.
     *
     * @param string $datetime Datetime in 'Y-m-d H:i:s' format.
     * @return string Formatted Jalali datetime (e.g., 1402/12/05 14:30).
     */
    public static function toJalali($datetime)
    {
        if (empty($datetime)) {
            return '';
        }

        list($date, $time) = explode(' ', $datetime);
        list($y, $m, $d) = explode('-', $date);
        list($h, $i, $s) = explode(':', $time);

        $jalali = self::gregorianToJalali($y, $m, $d);
        return $jalali[0] . '/' . str_pad($jalali[1], 2, '0', STR_PAD_LEFT) . '/' . str_pad($jalali[2], 2, '0', STR_PAD_LEFT) . ' ' . $h . ':' . $i;
    }

    /**
     * Gregorian to Jalali conversion.
     * Based on popular PHP function.
     */
    private static function gregorianToJalali($g_y, $g_m, $g_d)
    {
        $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

        $gy = $g_y - 1600;
        $gm = $g_m - 1;
        $gd = $g_d - 1;

        $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);
        for ($i = 0; $i < $gm; ++$i) {
            $g_day_no += $g_days_in_month[$i];
        }
        if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0))) {
            ++$g_day_no;
        }
        $g_day_no += $gd;

        $j_day_no = $g_day_no - 79;
        $j_np = floor($j_day_no / 12053);
        $j_day_no %= 12053;
        $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
        $j_day_no %= 1461;

        if ($j_day_no >= 366) {
            $jy += floor(($j_day_no - 1) / 365);
            $j_day_no = ($j_day_no - 1) % 365;
        }

        for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) {
            $j_day_no -= $j_days_in_month[$i];
        }
        $jm = $i + 1;
        $jd = $j_day_no + 1;

        return [$jy, $jm, $jd];
    }
}
