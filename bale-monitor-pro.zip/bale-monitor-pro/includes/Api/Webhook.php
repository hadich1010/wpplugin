<?php

namespace BaleMonitorPro\Api;

use BaleMonitorPro\Database\Database;

class Webhook
{
    private $database;
    private $apiClient;

    public function __construct(Database $database, Client $apiClient)
    {
        $this->database = $database;
        $this->apiClient = $apiClient;
    }

    public function registerHooks()
    {
        add_action('rest_api_init', [$this, 'registerEndpoint']);
    }

    public function registerEndpoint()
    {
        register_rest_route('bale/v1', '/webhook', [
            'methods' => 'POST',
            'callback' => [$this, 'handle'],
            'permission_callback' => [$this, 'verifyRequest'],
        ]);
    }

    public function verifyRequest($request)
    {
        // Optionally verify that request comes from Bale servers.
        // For now, return true but could check IP or token.
        return true;
    }

    public function handle($request)
    {
        $data = $request->get_json_params();

        if (!isset($data['message'])) {
            return new \WP_REST_Response(['ok' => false], 400);
        }

        $msg = $data['message'];
        $userId = $msg['from']['id'] ?? '';
        $username = $msg['from']['username'] ?? __('کاربر', 'bale-monitor-pro');
        $firstName = $msg['from']['first_name'] ?? '';
        $text = trim($msg['text'] ?? '');

        // ذخیره پیام
        if (!empty($text)) {
            $this->database->insertMessage($userId, $username, $text);
        }

        // پاسخ به دستورات
        if (in_array($text, ['/start', '/profile', 'profile'])) {
            $this->handleCommand($text, $userId, $firstName, $username);
        }

        return new \WP_REST_Response(['ok' => true], 200);
    }

    private function handleCommand($command, $userId, $firstName, $username)
    {
        if ($command === '/start') {
            $message = sprintf(
                "👋 سلام %s\n\nبه ربات ما خوش آمدی 🌿\nبرای دیدن پروفایل خودت دستور زیر رو بزن:\n/profile",
                $firstName
            );
        } elseif (in_array($command, ['/profile', 'profile'])) {
            $message = sprintf(
                "📌 اطلاعات پروفایل شما:\n\n👤 نام: %s\n🆔 Bale ID: %s\n🔖 Username: %s",
                $firstName,
                $userId,
                $username
            );
        } else {
            return;
        }

        $this->apiClient->request('sendMessage', [
            'chat_id' => $userId,
            'text'    => $message
        ]);
    }
}
