<?php

namespace BaleMonitorPro\Api;

class Client
{
    private $token;
    private $apiBase = 'https://tapi.bale.ai/bot';

    public function __construct()
    {
        $this->token = get_option('bale_bot_token');
    }

    public function setToken($token)
    {
        $this->token = $token;
        update_option('bale_bot_token', sanitize_text_field($token));
    }

    public function request($method, $params = [])
    {
        if (empty($this->token)) {
            return new \WP_Error('no_token', 'توکن تنظیم نشده است.');
        }

        $url = $this->apiBase . $this->token . '/' . $method;
        $response = wp_remote_post($url, [
            'headers' => [
                'Content-Type' => 'application/json; charset=utf-8'
            ],
            'body'    => json_encode($params),
            'timeout' => 20
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        return json_decode($body, true);
    }
}
