<?php

namespace BaleMonitorPro;

use BaleMonitorPro\Database\Database;
use BaleMonitorPro\Api\Client;
use BaleMonitorPro\Admin\AdminPage;
use BaleMonitorPro\Admin\Services\TokenService;
use BaleMonitorPro\Admin\Services\WebhookService;
use BaleMonitorPro\Admin\Services\MessageService;
use BaleMonitorPro\Admin\Views\TokenFormView;
use BaleMonitorPro\Admin\Views\WebhookSectionView;
use BaleMonitorPro\Admin\Views\MessagesView;
use BaleMonitorPro\Admin\Views\ApiResultRenderer;

class Bootstrap
{
    private static $instance = null;

    private $database;
    private $apiClient;
    private $webhook;
    private $admin;

    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
    }

    private function __construct()
    {
        $this->database = new Database();
        $this->apiClient = new Client();
        $this->webhook = new Api\Webhook($this->database, $this->apiClient);

        // ایجاد سرویس‌ها
        $tokenService = new TokenService($this->apiClient);
        $webhookService = new WebhookService($this->apiClient);
        $messageService = new MessageService($this->database);

        // ایجاد ویوها
        $apiResultRenderer = new ApiResultRenderer();
        $tokenFormView = new TokenFormView();
        $webhookSectionView = new WebhookSectionView($apiResultRenderer);
        $messagesView = new MessagesView();

        // ایجاد صفحه ادمین با وابستگی‌ها
        $this->admin = new AdminPage(
            $tokenService,
            $webhookService,
            $messageService,
            $tokenFormView,
            $webhookSectionView,
            $messagesView
        );

        // Hook into WordPress
        $this->webhook->registerHooks();
        $this->admin->registerHooks();
    }

    public static function activate()
    {
        Database::createTable();
    }

    public static function deactivate()
    {
        // Clean up if needed
    }
}
